#pragma once
#include <iostream>

// Problem 1c
/**
 * @brief Asks user for length of sequence, allocates memory, fills array with numbers, writes sequence to terminal and deletes memory when finished
 */
void createFibonacci();
