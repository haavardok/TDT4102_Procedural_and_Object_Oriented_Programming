#pragma once

// Problem 5b and 5c
int randomWithLimits(int lowerLimit, int upperLimit);